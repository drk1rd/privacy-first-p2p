from Crypto.Cipher import AES, PKCS1_OAEP
from Crypto.PublicKey import RSA
from Crypto.Random import get_random_bytes
import os, json, base64
from hashlib import sha256

def generate_rsa_keypair():
    key = RSA.generate(2048)
    with open("my_private.pem", "wb") as f:
        f.write(key.export_key())
    with open("my_public.pem", "wb") as f:
        f.write(key.publickey().export_key())
    print("RSA keypair generated as 'my_private.pem' and 'my_public.pem'.")

def load_public_key(path):
    with open(path, "rb") as f:
        return RSA.import_key(f.read())

def load_private_key(path):
    with open(path, "rb") as f:
        return RSA.import_key(f.read())

def encrypt_key_with_rsa(pub_key, aes_key):
    cipher = PKCS1_OAEP.new(pub_key)
    return cipher.encrypt(aes_key)

def decrypt_key_with_rsa(priv_key, enc_key):
    cipher = PKCS1_OAEP.new(priv_key)
    return cipher.decrypt(enc_key)

def encrypt_file_chunks(filepath):
    with open(filepath, "rb") as f:
        data = f.read()

    chunk_size = 1024
    chunks = [data[i:i+chunk_size] for i in range(0, len(data), chunk_size)]

    key = get_random_bytes(16)
    cipher = AES.new(key, AES.MODE_EAX)
    manifest = {"chunks": {}, "nonce": base64.b64encode(cipher.nonce).decode(), "filename": os.path.basename(filepath)}

    for i, chunk in enumerate(chunks):
        cipher = AES.new(key, AES.MODE_EAX)
        ciphertext, tag = cipher.encrypt_and_digest(chunk)
        chunk_hash = sha256(ciphertext).hexdigest()
        manifest["chunks"][chunk_hash] = base64.b64encode(ciphertext).decode()

    return key, manifest

def decrypt_file_chunks(manifest, key):
    out_path = "RECEIVED_" + manifest["filename"]
    with open(out_path, "wb") as f:
        for chunk_hash, chunk_data in manifest["chunks"].items():
            cipher = AES.new(key, AES.MODE_EAX)
            ciphertext = base64.b64decode(chunk_data)
            plaintext = cipher.decrypt(ciphertext)
            f.write(plaintext)
    print(f"File reconstructed: {out_path}")